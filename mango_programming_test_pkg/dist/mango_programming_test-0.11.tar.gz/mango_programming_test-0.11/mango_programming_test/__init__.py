
"""
Created on Sun Sep 29
For Mango Solutions Python test
For any questions please contact Claire Blejean: claire.blejean@gmail.com

"""

name = "mango_programming_test"